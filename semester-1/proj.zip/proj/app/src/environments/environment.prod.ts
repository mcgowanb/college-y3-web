export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyB-yo7QdsvT4wcr-Z9cGlbsIcWFSspNl_Q", 
    authDomain: "web-proj-auth.firebaseapp.com", 
    databaseURL: "https://web-proj-auth.firebaseio.com", 
    projectId: "web-proj-auth", 
    storageBucket: "", 
    messagingSenderId: "390928824998" 
  }
};
