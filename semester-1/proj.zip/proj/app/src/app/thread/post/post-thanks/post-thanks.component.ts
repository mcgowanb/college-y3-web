import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-post-thanks',
  templateUrl: './post-thanks.component.html',
  styleUrls: ['./post-thanks.component.css']
})
export class PostThanksComponent implements OnInit {
//Author Brian McGowan
  @Input() postThanks: any[];
  constructor() { }

  ngOnInit() {
  }

}
