import { PostModalComponent } from '../../modals/post-modal/post-modal.component';
import { NotificationMsg } from '../../models/notification.model';
import { DialogService } from 'ng2-bootstrap-modal/dist';
import { error } from 'util';
import { selector } from 'rxjs/operator/publish';
import { ConfirmModalClose, GenericModalClose, PostModalClose } from '../../models/modals.model';
import { PostActionType, NotificationClass } from '../../models/enum';
import { PostAction } from '../../models/postAction';
import { Thanks } from '../../models/thanks';
import { DataService } from '../../services/data.service';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ThreadAction } from '../../models/threadAction';
import * as _ from 'lodash';
import { GenericModalComponent } from '../../modals/generic-modal/generic-modal.component';

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent implements OnInit {

  @Input() post: any;
  @Input() index: number;
  @Input() userID: number;
  @Output() error: EventEmitter<Response>;
  @Output() threadActionEvt: EventEmitter<ThreadAction>;
  @Output() notificationEvt: EventEmitter<NotificationMsg>;

  postThanks: Thanks[];
  thanksReady = false;
  hasThankedPost = false;

  //Author Brian McGowan
  constructor(private _dataService: DataService, private _dialogService: DialogService) {
    this.error = new EventEmitter<Response>();
    this.threadActionEvt = new EventEmitter<ThreadAction>();
    this.notificationEvt = new EventEmitter<NotificationMsg>();
  }

  ngOnInit() {
    this.loadPostThanks();
  }

  //load thanks for the post
  loadPostThanks() {
    this._dataService.getPostThanks(this.post.PostID).subscribe((res) => {
      this.postThanks = res;
      this.thanksReady = true;
      this.hasUserThankedPost();
    }, (error: Response) => this.error.emit(error))

  }

  //determine the button that was clicked and take whatever action is necessary
  postButtonClicked(evt: PostAction) {
    switch (evt.type) {
      case PostActionType.deletePost:
        this.deletePostConfirmation(evt);
        break;
      case PostActionType.removeThanks:
        this.removeThanks(evt);
        break;
      case PostActionType.editPost:
        this.editPost(evt);
        break;
      case PostActionType.reply:
      case PostActionType.report:
        this.blankAction(evt);
        break;
      case PostActionType.thankPost:
        this.addThanks(evt);
        break;
      default:
        this.notificationEvt.emit(new NotificationMsg(NotificationClass.warning, 'Oops!', 'Unknown action requested'));
        break;
    }
  }

  //loads a modal confirmation box to delete the post
  deletePostConfirmation(evt: PostAction) {
    this._dialogService.addDialog(GenericModalComponent, {
      title: 'Confirm Post Deletion',
      html: `<h1>Are you sure you want to delete this post?</h1><p><small> Deleting is permanant and cannot be undone</small></p>`,
      showActionButtons: true
    }).subscribe((result: GenericModalClose) => {
      if (result.action) {
        this.deletePost(evt);
      }
    });
  }


  deletePost(action: PostAction) {
    this._dataService.deletePost(action.postID, action.ownerID).subscribe((res) => {
      this.notificationEvt.emit(new NotificationMsg(NotificationClass.success, 'Success', 'Post successfully deleted'));
      this.threadActionEvt.emit(new ThreadAction(PostActionType.deletePost, this.index));

    }, (error: Response) => this.error.emit(error));
  }

  addThanks(action: PostAction) {
    //todo - Need to replace the user id with the logged in user
    this._dataService.addThanks(action.postID, this.userID).subscribe((res) => {
      this.loadPostThanks();
    }, (error: Response) => this.error.emit(error));
  }

  removeThanks(action: PostAction) {
    this._dataService.removeThanks(action.postID, this.userID).subscribe((res) => {
      this.loadPostThanks();
    }, (error: Response) => this.error.emit(error));
  }

  //generic placeholer function for functionality not implemented
  blankAction(evt: PostAction) {
    this.notificationEvt.emit(new NotificationMsg(NotificationClass.success, 'Success', 'Generic success here'));
  }

  hasUserThankedPost() {
    let res = _.findIndex(this.postThanks, (t: Thanks) => {
      return t.UserID == this.userID;
    });
    this.hasThankedPost = res > -1 ? true : false;
  }

  editPost(evt: PostAction) {
    this._dialogService.addDialog(PostModalComponent, {
      content: this.post.Content,
      title: 'Edit Post'
    }).subscribe((result: PostModalClose) => {
      if (result.isDirty) {
        this.updatePost(result);
      }
    }, (error: Response) => this.error.emit(error));
  }

  //takes an object from the modal with the updated information.
  updatePost(closObj: PostModalClose) {
    this._dataService.updatePost({ content: closObj.content, postID: this.post.PostID, modifiedDate: closObj.modifiedDate })
      .subscribe((res) => {
        this.post.Content = closObj.content;
        this.post.Created = closObj.modifiedDate;
        this.notificationEvt.emit(new NotificationMsg(NotificationClass.success, 'Success', 'Post successfully updated'));

      }, (error: Response) => this.error.emit(error))
  }
}
