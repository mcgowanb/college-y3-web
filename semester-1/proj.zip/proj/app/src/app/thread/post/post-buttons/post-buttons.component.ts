import { DataService } from '../../../services/data.service';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { PostAction } from '../../../models/postAction';
import { PostActionType } from '../../../models/enum';

@Component({
  selector: 'app-post-buttons',
  templateUrl: './post-buttons.component.html',
  styleUrls: ['./post-buttons.component.css']
})
export class PostButtonsComponent implements OnInit {

  @Input() postID: number;
  @Input() postIdx: number;
  @Input() ownerID: number;
  @Input() postContent: string;
  @Input() userID: number;
  @Input() hasThankedPost: boolean;
  
  @Output() buttonClick: EventEmitter<PostAction>;
  private _postAction: PostAction;
  constructor(private _dataService: DataService) {
    this.buttonClick = new EventEmitter<PostAction>();
  }
  //Author Brian McGowan
  //All buttons emit the same event object with a different property set depending on the buton pushed.These are passed to the 
  //post component wich handles the logic for these.
  ngOnInit() {
    this._postAction = new PostAction(this.postID, this.ownerID,  this.postContent, this.postIdx);
  }

  addThanks() {
    this._postAction.type = PostActionType.thankPost;
    this.buttonClick.emit(this._postAction);
  }

  removeThanks() {
    this._postAction.type = PostActionType.removeThanks;
    this.buttonClick.emit(this._postAction);
  }

  deletePost() {
    this._postAction.type = PostActionType.deletePost;
    this.buttonClick.emit(this._postAction);    
  }

  reply() {
    this._postAction.type = PostActionType.reply;
    this.buttonClick.emit(this._postAction);    
  }

  reportPost() {
    this._postAction.type = PostActionType.report;
    this.buttonClick.emit(this._postAction);    
  }

  editPost() {
    this._postAction.type = PostActionType.editPost;
    this.buttonClick.emit(this._postAction);    
  }

  hasFullPermission():boolean{
    return (this.userID === this.ownerID) ? true : false;
  }

}
