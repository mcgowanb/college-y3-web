import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PostThanksComponent } from './post-thanks.component';

describe('PostThanksComponent', () => {
  let component: PostThanksComponent;
  let fixture: ComponentFixture<PostThanksComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PostThanksComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PostThanksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
