import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-post-user-details',
  templateUrl: './post-user-details.component.html',
  styleUrls: ['./post-user-details.component.css']
})
export class PostUserDetailsComponent implements OnInit {
//Author Brian McGowan
  @Input() details: any;
  constructor() { }

  ngOnInit() {
  }

}
