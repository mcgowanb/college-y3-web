import { AuthService } from '../services/auth.service';
import { PostModalComponent } from '../modals/post-modal/post-modal.component';
import { ThreadAction } from '../models/threadAction';
import { NotificationMsg } from '../models/notification.model';
import { GenericModalComponent } from '../modals/generic-modal/generic-modal.component';
import { PostModalClose, ConfirmModalClose, GenericModalClose } from '../models/modals.model';
import { PostActionType, NotificationClass } from '../models/enum';
import { PostAction } from '../models/postAction';
import { DataService } from '../services/data.service';
import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import 'rxjs/add/operator/switchMap';
import { Title } from "@angular/platform-browser";
import { ToastsManager } from 'ng2-toastr';
import { DialogService } from 'ng2-bootstrap-modal';
import * as _ from 'lodash';
import { EmailService } from '../services/email.service';

@Component({
  selector: 'app-thread',
  templateUrl: './thread.component.html',
  styleUrls: ['./thread.component.css']
})
export class ThreadComponent implements OnInit {

  private _threadID: number;
  public thread: any;
  public viewReady = false;

  private _userID: number

  hasFollowedThread: boolean;

  //Author Brian McGowan
  constructor(private _auth: AuthService, private route: ActivatedRoute, private router: Router, private _dataService: DataService, private _titleService: Title, private _emailService: EmailService,
    public toastr: ToastsManager, vcr: ViewContainerRef, private _dialogService: DialogService) {
    this.toastr.setRootViewContainerRef(vcr);
    this._userID = _auth.userID;
  }

  //Author Brian McGowan
  ngOnInit() {
    this._threadID = Number(this.route.snapshot.paramMap.get('threadID'));
    this.loadThreadData();
    this.hasUserFollowedThread();
  }

  //Author Brian McGowan
  loadThreadData() {
    this._dataService.getThreadDetails(this._threadID).subscribe((res) => {
      if (!res.thread) {
        this.router.navigate(['not-found'])
      }
      this.thread = res;
      this.viewReady = true;
      this._titleService.setTitle(res.thread.Title);

    });
  }

  //Author Brian McGowan
  get userID(): number {
    return this._userID;
  }

  //Author Brian McGowan
  get threadID(): number {
    return this._threadID;
  }


  //Author Brian McGowan
  displayError(error: Response) {
    this._dialogService.addDialog(GenericModalComponent, {
      html: `<p>An error has occurred. The following message was reported by the server</p><p>${error.statusText}</p>`,
      time: 5000
    }).subscribe((result: GenericModalClose) => {

    });
  }
  //Author Brian McGowan
  displayToast($event: NotificationMsg) {
    switch ($event.cls) {
      case NotificationClass.success:
        this.toastr.success($event.message, $event.title);
        break;
      case NotificationClass.warning:
        this.toastr.warning($event.message, $event.title);
        break;
    }
  }
  //Author Brian McGowan
  updateThread($event: ThreadAction) {
    switch ($event.type) {
      case PostActionType.deletePost:
        this.thread.posts.splice($event.aryIndex, 1);
        break;
    }
  }

  //Author Brian McGowan
  addPost() {
    this._dialogService.addDialog(PostModalComponent, {
      content: '',
      title: 'Add Reply'
    }).subscribe((result: PostModalClose) => {
      if (result.isDirty) {
        this.createPost(result);
      }
    }, (error: Response) => this.displayError(error));
  }
  //Author Brian McGowan
  createPost(post: PostModalClose) {
    this._dataService.createPost({
      content: post.content,
      createdDate: post.modifiedDate,
      userID: this._userID,
      threadID: this.thread.thread.ThreadID
    }).subscribe((res) => {
      this.loadThreadData();
      this.displayToast(new NotificationMsg(NotificationClass.success, 'Success!', 'Post Sucessfully added'))

      //  EmailService - Send email notification to author that update of thread occured 
      this._emailService.emailAuthorThreadUpdate(this._threadID).subscribe ((res) => {})
    });
  }

  // thread follow stuff/////////////////////////////////////////////////////////// 
  //Kate O'Neill
  addFollow($event) {
    this.hasFollowedThread = true;
    //todo - Need to replace the user id with the logged in user 
    this._dataService.addFollow($event, this._userID).subscribe((res) => {
    }, (error: Response) => this.displayError(error));
  }
  //Kate O'Neill
  removeFollow($event) {
    this.hasFollowedThread = false;
    this._dataService.removeFollow($event, this._userID).subscribe((res) => {
    }, (error: Response) => this.displayError(error));
  }


  //Kate O'Neill
  hasUserFollowedThread() {

    this._dataService.checkFollowed(this._userID).subscribe((res) => {

      let result = _.findIndex(res, (o) => {
        return o.UserID == this._userID && o.ThreadID == this._threadID;
      });

      this.hasFollowedThread = result > -1 ? true : false;
    })

  }

  ////////////////////////////////////////////////////////////// 
  //Author Brian McGowan
  deleteThread() {
    this._dialogService.addDialog(GenericModalComponent, {
      title: 'Notice',
      html: `<h1>Are you sure you want to delete this thread?</h1><p><small>Deleting is permanant and cannot be undone</small></p>`,
      showActionButtons: true
    }).subscribe((result: GenericModalClose) => {
      if (result.isClosed && result.action) {
        this._dataService.deleteThread(this._threadID).subscribe((res) => {
          this.displayToast(new NotificationMsg(NotificationClass.success, 'Success!', 'Thread Deleted.'))
          setTimeout(() => { this.router.navigate(['/dashboard']); }, 2000)
        }, (error: Response) => this.displayError(error))
      }
    }, (error: Response) => this.displayError(error));
  }
}
