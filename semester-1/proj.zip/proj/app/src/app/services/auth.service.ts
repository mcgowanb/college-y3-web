import { NotificationService } from './notification.service';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Rx';
import * as firebase from 'firebase/app';
import { Injectable } from '@angular/core';
import { AngularFireAuth } from 'angularfire2/auth';
import { _firebaseAppFactory } from 'angularfire2/firebase.app.module';
import { User } from '../models/user';
import { DataService } from './data.service';


@Injectable()
export class AuthService {
  private _user: Observable<firebase.User>;
  private _userDetails: any;
  private _success: boolean;
  private _loading = true;


  constructor(private _firebaseAuth: AngularFireAuth, private _router: Router, private _notifier: NotificationService, private _dataService: DataService) {
    this._user = _firebaseAuth.authState;
    this.subscribeToUser();

  }
  //Brian McGowan
  get user(): Observable<firebase.User> {
    return this._user;
  }

  //Brian McGowan
  get userID() {
    return (this._userDetails) ? this._userDetails.UserID : -1;
  }

  //Brian McGowan
  get userDetails() {
    return this._userDetails;
  }

  //Brian McGowan  
  get isLoading() {
    return this._loading;
  }

  //Brian McGowan  
  subscribeToUser() {
    this._firebaseAuth.authState.subscribe((user: firebase.User) => {
      if (user) {
        this._dataService.getUserDetails(user.uid).subscribe((res: any) => {
          this._userDetails = res;
          this._loading = false;
        });
      }
      else {
        this._userDetails = null;
        this._loading = false;
      }
    })
  }

  //Brian McGowan
  login(email: string, password: string) {
    this._notifier.display(false, '', '');
    this._firebaseAuth.auth.signInWithEmailAndPassword(email, password).then((user: firebase.User) => {

      this._firebaseAuth.authState.subscribe((user: firebase.User) => {
        if (user) {
          localStorage.setItem('emailDisplay', email);
          this._dataService.getUserDetails(user.uid).subscribe((res) => {
            this._userDetails = <User>res;
            this._router.navigate(['dashboard'])
          });
        }
        else {
          this._userDetails = null;
          this._router.navigate(['login']);
        }
      })

    }).catch(err => {
      console.log('Something went wrong:', err.message);
      this._notifier.display(true, err.message, 'fail');
    })
  }

  //Brian McGowan  
  logout() {
    this._firebaseAuth.auth.signOut()
      .then((res) => {
        this._userDetails = null;
        this._router.navigate(['/login'])
      });
  }

  //Brian McGowan  
  register(user: User) {
    this._notifier.display(false, '', '');
    this._firebaseAuth.auth.createUserWithEmailAndPassword(user.Email, user.Password).then((res: firebase.User) => {
      user.Uid = res.uid;
      this._dataService.createUser(user).subscribe(uData => {
        this._notifier.display(false, '','');
        let message = 'Registration Successful, you will shortly be redirected to the login page';
        this._notifier.display(true, message, 'success');
        this._firebaseAuth.auth.signOut();
        setTimeout(() => {
          this._router.navigate(['/login'])
        }, 5000)


      });
    }).catch(err => {
      console.log(err);
      this._notifier.display(true, err.message, 'fail');
    });
  }
  
  ///////////////////////////////////////
  // Kate O'Neill
  updateUser(user: User) {
    this._notifier.display(false, '', '');
    //this._firebaseAuth.auth.currentUser.updateEmail(user.Email);
    //update password here later
    //console.log(user+" u");
    this._dataService.updateUser(user);
    this._dataService.updateUser(user).subscribe(uData => {
      let message = 'Update Successful';
      this._notifier.display(true, message, 'success');
      console.log("calling ");
    })
  }
  //Kate O'Neill
  updatePassword(password: string): Promise<any> {
    this._notifier.display(false, '', '');
    console.log("In update password method");
    var user = firebase.auth().currentUser;
    console.log(user);
    var newPassword = password;

    return user.updatePassword(newPassword)
    //////////////////////////////////////////////////
  }

}
