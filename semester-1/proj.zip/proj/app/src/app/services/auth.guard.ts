import { AngularFireAuth } from 'angularfire2/auth';
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { AuthService } from './auth.service';

@Injectable()
export class AuthGuard implements CanActivate {

  isLoggedIn$: Observable<boolean>;

  constructor(private _router: Router, private _firebaseAuth: AngularFireAuth) {
   
  }

    //Brian McGowan
  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {

    return this._firebaseAuth.authState.map((auth) =>  {
      if(auth == null) {
        this._router.navigate(['/login']);
        return false;
      } else {
        return true;
      }
    });
   

  }
}
