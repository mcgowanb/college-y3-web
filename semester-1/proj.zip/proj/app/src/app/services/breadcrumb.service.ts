import { CategoryList } from '../models/category';
import { Thread, ThreadList } from '../models/thread';
import { Observable } from 'rxjs/Rx';
import { Http, Response } from '@angular/http';
import { Injectable } from '@angular/core';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';


//  Breadcrumb service
//  Get the data for current breadcrumb


@Injectable()
export class BreadcrumbService {
  private _baseURL: string;

  constructor(private _http: Http) {
    this._baseURL = 'http://localhost:8080/';
    // this._baseURL = 'https://boiling-citadel-29540.herokuapp.com/';
  }

  private _errorHandler(error: Response) {
    return Observable.throw(error);
  }

  //  Function to get the name of a category based on category ID
  getCategoryTitle(categoryID: string) {
    return this._http.get(`${this._baseURL}breadcrumb/category/${categoryID}`)
      .map((res: Response) => res)
      .catch(this._errorHandler);
  }

  //  Function to get the title of a thread based on thread ID
  getThreadTitle(threadID: string) {
    return this._http.get(`${this._baseURL}breadcrumb/thread/${threadID}`)
      .map((res: Response) => res)
      .catch(this._errorHandler);
  }

  //  Function to get the category id of a thread based on thread ID
  getThreadCategoryID(threadID: string) {
    return this._http.get(`${this._baseURL}breadcrumb/threadcategoryid/${threadID}`)
      .map((res: Response) => res)
      .catch(this._errorHandler);
  }

  //  Function to get the category title of a thread based on thread ID
  getThreadCategoryTitle(threadID: string) {
    return this._http.get(`${this._baseURL}breadcrumb/threadcategoryname/${threadID}`)
      .map((res: Response) => res)
      .catch(this._errorHandler);
  }
}
