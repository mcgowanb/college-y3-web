import { NgClass } from '@angular/common/src/directives/ng_class';
import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable()
export class NotificationService {
  private sub = new Subject<any>();
  public emitter = this.sub.asObservable();

    //Brian McGowan & Kate O'Neill
  display(display, message, type) {
    if (type == 'success') {
      this.sub.next({ display, message, class: "alert alert-success" });
    }
    else {
      this.sub.next({ display, message, class: "alert alert-danger" });
    }
  }
}
