import { User } from '../models/user';
import { DialogService } from '../../../node_modules/ng2-bootstrap-modal';
import { CategoryList } from '../models/category';
import { Thread, ThreadList } from '../models/thread';
import { Http, Response } from '@angular/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Thanks } from '../models/thanks';



@Injectable()
export class DataService {

  private _baseURL: string;

  constructor(private _http: Http) {
    this._baseURL = 'http://localhost:8080/'
    // this._baseURL = 'https://boiling-citadel-29540.herokuapp.com/' 
  }

  //Brian McGowan
  private _errorHandler(error: Response) {
    return Observable.throw(error);
  }

  //Brian McGowan
  getAllThreads() {
    return this._http.get(`${this._baseURL}threads`)
      .map((res: Response) => <ThreadList[]>res.json())
      .catch(this._errorHandler);
  }

  //Brian McGowan
  getThreadsListByCategoryID(categoryID: number) {
    return this._http.get(`${this._baseURL}threads?categoryID=${categoryID}`)
      .map((res: Response) => <ThreadList[]>res.json())
      .catch(this._errorHandler);
  }

  //Brian McGowan
  getAllCategories() {
    return this._http.get(`${this._baseURL}categories`)
      .map((res: Response) => <CategoryList[]>res.json())
      .catch(this._errorHandler);
  }

  //Brian McGowan
  getThreadDetails(threadID: number) {
    return this._http.get(`${this._baseURL}threads/${threadID}`)
      .map((res: Response) => <CategoryList[]>res.json())
      .catch(this._errorHandler);
  }

  //Brian McGowan
  deletePost(postID: number, userID: number) {
    return this._http.delete(`${this._baseURL}posts/${postID}?userID=${userID}`).map((res: Response) => res.json())
      .catch(this._errorHandler);
  }

  //Brian McGowan
  addThanks(postID: number, userID: number) {
    return this._http.post(`${this._baseURL}thanks/add`, { pid: postID, uid: userID }).map((res: Response) => {
      res.json()
    }).catch(this._errorHandler);
  }

    //Brian McGowan
  removeThanks(postID: number, userID: number) {
    return this._http.post(`${this._baseURL}thanks/remove`, { pid: postID, uid: userID }).map((res: Response) => {
      res.json()
    }).catch(this._errorHandler);
  }
  //  --------------------------------------------------------------------------
  //kate O'Neill
  addFollow(threadID: number, userID: number) {
    return this._http.post(`${this._baseURL}threads/follow`, { tid: threadID, uid: userID }).map((res: Response) => {
      res.json()
    }).catch(this._errorHandler);
  }

  removeFollow(threadID: number, userID: number) {
    return this._http.post(`${this._baseURL}threads/unfollow`, { tid: threadID, uid: userID }).map((res: Response) => {
      res.json()
    }).catch(this._errorHandler);
  }

  // ---------------------------------------------------------------------------------------------
  //Kate O'Neill
  //get followed threads
  getFollowedThreads(userID: number) {
    return this._http.get(`${this._baseURL}thread/followed/${userID}`)
      .map((res: Response) => <ThreadList[]>res.json())
      .catch(this._errorHandler);
  }
  ///--------------------------------------------------------
//check for button if followed or not
 //Kate O'Neill
checkFollowed(userID: number) {
  return this._http.get(`${this._baseURL}threads/myFollowedThreads/${userID}`)
  .map((res: Response) => <ThreadList[]>res.json())
  .catch(this._errorHandler);
}


  ////--------------------------------
  getPostThanks(postID: number) {
    return this._http.get(`${this._baseURL}thanks/?pid=${postID}`)
      .map((res: Response) => <Thanks[]>res.json())
      .catch(this._errorHandler);
  }

    //Brian McGowan
  updatePost(data) {
    return this._http.put(`${this._baseURL}posts`, data)
      .map((res: Response) => res.json())
      .catch(this._errorHandler);
  }

    //Brian McGowan
  createPost(data) {
    return this._http.post(`${this._baseURL}posts`, data).map((res: Response) => {
      res.json()
    }).catch(this._errorHandler);
  }

    //Brian McGowan
  createUser(data) {
    return this._http.post(`${this._baseURL}users`, data).map((res: Response) => res.json())
      .catch(this._errorHandler);
  }
  //Brian McGowan
  getUserDetails(uid: string) {
    return this._http.get(`${this._baseURL}users/${uid}`)
      .map((res: Response) => res.json())
      .catch(this._errorHandler);
  }
  //Brian McGowan
  createThread(thread: Thread) {
    return this._http.post(`${this._baseURL}threads`, thread)
      .map((res: Response) => res.json())
      .catch(this._errorHandler);
  }

// =================================
 //Kate O'Neill
  updateUser(user: User){;
    return this._http.put(`${this._baseURL}users`, user)
      .map((res: Response) => res.json())
      .catch(this._errorHandler);
  }
//========================================
  deleteThread(threadID: number) {
    return this._http.delete(`${this._baseURL}threads/${threadID}`).map((res: Response) => res.json())
      .catch(this._errorHandler);
  }
}
