import { NewThreadComponent } from './new-thread/new-thread.component';
import { UserDetailsComponent } from './users/user-details/user-details.component';
import { AuthGuard } from './services/auth.guard';
import { LoginComponent } from './users/login/login.component';
import { RegisterComponent } from './users/register/register.component';
import { NgModule } from '@angular/core';
import { ExtraOptions, RouterLink, RouterModule, Routes } from '@angular/router';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { ThreadComponent } from './thread/thread.component';
import { DashboardComponent } from './dashboard/dashboard.component';

const appRoutes: Routes = [
    {
        path: '',
        redirectTo: '/dashboard',
        pathMatch: 'full',
        canActivate: [AuthGuard]
    },
    {
        path: 'dashboard',
        component: DashboardComponent,
        canActivate: [AuthGuard]        
    },
    {
        path: 'home',
        component: DashboardComponent,
        canActivate: [AuthGuard]        
    },
    {
        path: 'viewThread/:threadID',
        component: ThreadComponent,
        data: { pageTitle: 'View Thread' },
        canActivate: [AuthGuard]        
    },
    {
        path: 'login',
        component: LoginComponent
    },
    {
        path: 'register',
        component: RegisterComponent
    },
    {
        path: 'userDetails',
        component: UserDetailsComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'newThread',
        component: NewThreadComponent,
        canActivate: [AuthGuard]
    },
    {
        path: '**',
        component: PageNotFoundComponent
    }
];

const config: ExtraOptions = {
    useHash: true,
  };


@NgModule({
    imports: [
        RouterModule.forRoot(appRoutes, config)
    ],
    exports: [
        RouterModule
    ]
})

export class Routing { }
