import { AuthService } from '../services/auth.service';
import { DataService } from '../services/data.service';
import { ThreadList } from '../models/thread';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-followed-threads',
  templateUrl: './followed-threads.component.html',
  styleUrls: ['./followed-threads.component.css']
})
export class FollowedThreadsComponent implements OnInit {
  public favouritesList: ThreadList[];
  public loading = true;
  

  constructor(private _dataService: DataService, private _auth: AuthService) { 
    this._dataService.getFollowedThreads(_auth.userID).subscribe(res => {
      this.favouritesList = res;
      this.loading = false;
    }, (err) => {
      console.log(err);
    });
  }

  ngOnInit() {
  }

}
