//Author Brian McGowan
export class Thanks{
    public UserID: number;
    public UserName: string;

    constructor(uID: number, userName: string){
        this.UserID = uID;
        this.UserName = userName;
    }
}