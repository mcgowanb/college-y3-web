export class BreadCrumb {
    public path: string;
    public text: string;
    public visible?: boolean;

    constructor(path: string, text: string) {
        this.path = path;
        this.text = text;
        this.visible = true;
    }
}
