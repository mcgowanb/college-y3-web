//Author Brian McGowan
import { NotificationClass } from "./enum";

export class NotificationMsg{
    message: string;
    title: string;
    cls: NotificationClass;

    constructor(cls: NotificationClass, title: string, msg: string){
        this.cls = cls;
        this.message = msg;
        this.title = title;
    }
}