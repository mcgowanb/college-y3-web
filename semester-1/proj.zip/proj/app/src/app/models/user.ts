//Author Brian McGowan
export class User{
    public Name: string;
    public UserName: string;
    public Email: string;
    public Password: string;
    public UserID: number;
    public Uid: string;

    constructor(){}
}