//Author Brian McGowan
import { PostActionType } from './enum';
export class ThreadAction {
    type: PostActionType;
    aryIndex: number;

    constructor(type: PostActionType, idx: number) {
        this.type = type;
        this.aryIndex = idx;
    }
} 