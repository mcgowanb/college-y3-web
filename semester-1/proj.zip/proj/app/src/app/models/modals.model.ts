//Author Brian McGowan
export interface GenericModalOpen {
    title: string;
    html: string;
    time: number;
    showActionButtons: false;    
}

export interface GenericModalClose {
    isClosed: boolean;
    action: boolean;
}

export interface ConfirmModalOpen {
    message: string;
}

export interface ConfirmModalClose {
    confirm: boolean;
}

export interface PostModalOpen {
    content: string;
    threadID: number;
    title: string;
}

export interface PostModalClose {
    content: string;
    isDirty: boolean;
    modifiedDate: string;
    threadID: number;
}