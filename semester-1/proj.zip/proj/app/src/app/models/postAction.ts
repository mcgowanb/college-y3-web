//Author Brian McGowan
import { PostActionType } from "./enum";

export class PostAction {
    postID: number;
    ownerID: number
    content: string;
    type : PostActionType;
    postIdx: number;

    constructor(postID: number, ownerID: number, content: string, idx: number, type : PostActionType = -1) {
        this.postID = postID;
        this.ownerID = ownerID;
        this.content = content;
        this.type = type;
        this.postIdx = idx;
    }
}