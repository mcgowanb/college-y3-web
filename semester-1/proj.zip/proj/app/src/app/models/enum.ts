//Author Brian McGowan
export enum PostActionType {
    noAction = -1,
    editPost = 1,
    deletePost = 2,
    thankPost = 3,
    removeThanks = 4,
    reply = 5,
    report = 6
}

export enum NotificationClass{
    success = 1,
    warning = 2,
}