/////////////////////
// Kate O'Neil
////////////////////
export class CategoryList{
    constructor(){}
    public categoryID: string;
    public name: string;
    public threads: number;
}