//Author Brian McGowan
import * as moment from 'moment';

export class ThreadList{
    constructor(){}
    public threadID: string;
    public category: string;
    public userID: Number;
    public user: string;
    public title: string;
    public rating: number;
    public createdDate: moment.Moment;
    public PostCount: number;
}

export class Thread{
    constructor(){}
    public categoryID: string;
    public userID: Number;
    public title: string;
    public rating: number;
    public body: string;
    public createdDate: string;    
}