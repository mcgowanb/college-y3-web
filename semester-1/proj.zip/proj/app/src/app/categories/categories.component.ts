////////////////////////////
// Kate O'Neill
/////////////////////////////
import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { CategoryList } from '../models/category';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-categories',
  templateUrl: './categories.component.html',
  styleUrls: ['./categories.component.css']
})
export class CategoriesComponent implements OnInit {

  @Output() filterCategory = new EventEmitter<any>();

  public categoriesList: CategoryList[];
  public loading = true;
  public selectedCategory: number;
  constructor(private _dataService: DataService) { }

  ngOnInit() {
    this._dataService.getAllCategories().subscribe(res => {
      this.categoriesList = res;
      this.loading = false;
    }, (err) => {
      console.log(err);
    });
    
  }

  loadCategory(categoryID: number, title: string) {
    this.selectedCategory = categoryID;
    this.filterCategory.emit({ categoryID : categoryID, categoryTitle: title});
   
  }

}
