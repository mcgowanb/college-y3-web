import { Title } from '@angular/platform-browser';
import { NavBarComponent } from '../nav-bar/nav-bar.component';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { SharedService } from '../services/shared.service';
import { ThreadsListComponent } from '../threads-list/threads-list.component';
import { Component, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  @ViewChild(ThreadsListComponent) private threadListComponent;
  //for later matching of selected from navbar and side menu
  //@ViewChild (NavBarComponent) private navBarComponent;

  constructor(private route:ActivatedRoute, private _titleService: Title) { }

  ngOnInit() {
    this._titleService.setTitle('Dashboard');
    this.route.paramMap.subscribe((params:ParamMap)=>{
      
    });
  }

  filterCategory($event){
    //this._sharedService.emitChange('Data from child');
    this.threadListComponent.filterThreadsByCategory($event);
   // this.navBarComponent 
  }

}
