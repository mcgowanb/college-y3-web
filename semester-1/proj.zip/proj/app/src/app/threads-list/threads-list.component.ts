import { ActivatedRoute, ParamMap } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { ThreadList } from '../models/thread';
import { Component, OnInit } from '@angular/core';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-threads-list',
  templateUrl: './threads-list.component.html',
  styleUrls: ['./threads-list.component.css']
})
export class ThreadsListComponent implements OnInit {

  public threadsList: ThreadList[];
  public loading = true;

  constructor(private _dataService: DataService, private _auth: AuthService, private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.paramMap.subscribe((params: ParamMap) => {
      if (params.has('category')) {
        this.filter({ categoryID: params.get('category'), categoryTitle: "" });
      }
      else {
        this.loadAllThreads();
      }
    });
  }

  filterThreadsByCategory($event) {
    if ($event.categoryID == -1)
      this.loadAllThreads();
    else this.filter($event);
  }
  loadAllThreads() {
    this._dataService.getAllThreads().subscribe(res => {
      this.threadsList = res;
      this.loading = false;
    }, (err) => {
      console.log(err);
    });
  }

  filter($event) {
    this._dataService.getThreadsListByCategoryID($event.categoryID).subscribe(res => {
      this.loading = false;
      this.threadsList = res;
    }, (err) => {
      console.log(err);
    });
  }


}


