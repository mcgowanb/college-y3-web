import {AuthService} from './services/auth.service';

import { DashboardComponent } from './dashboard/dashboard.component';
import { Component, ViewChild } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  @ViewChild(DashboardComponent) private dashboardComponent;
 
  public auth: AuthService;
  constructor(auth: AuthService){
    this.auth = auth;
  }
  

  ngOnInit() {
    
  }

  passInfo($event){
    event= $event;
    this.onActivate(this.dashboardComponent)
    this.dashboardComponent.filterCategory($event);
    
  }
  onActivate(DashboardComponent){
    this.dashboardComponent = DashboardComponent;
  }

}
