

////////////////////////////////////////////////////////////////
//Kate O'Neill
////////////////////////////////////////////////////////////////
import { AuthService } from '../../services/auth.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Component, OnInit, ElementRef, ViewChild, HostListener } from '@angular/core';
import { DialogComponent, DialogService } from "ng2-bootstrap-modal";
import { GenericModalOpen, GenericModalClose } from '../../models/modals.model';
import { NotificationService } from '../../services/notification.service';

@Component({
  selector: 'app-password-modal',
  templateUrl: './password-modal.component.html',
  styleUrls: ['./password-modal.component.css']
})

export class PasswordModalComponent extends DialogComponent<GenericModalOpen, GenericModalClose> implements OnInit {
  title = 'Error';
  html: string;
  time: -1;
  ngForm: FormGroup;
  showActionButtons = false;
  public password: string;
  public confirmPassword: string;

  constructor(private _fb: FormBuilder, private _auth: AuthService, dialogService: DialogService, private _notifier: NotificationService) {
    super(dialogService);
    this._notifier.display(false,'','');
    this.createForm();
  }

  createForm() {
    this.ngForm = this._fb.group({
      password: ['', Validators.compose([Validators.required,Validators.minLength(6)])],
      confirmPassword: ['', Validators.compose([Validators.required,Validators.minLength(6)])],
    }, { validator: this.matchingPassword('password', 'confirmPassword') })
  }

  @HostListener('window:keyup', ['$event'])
  keyboardInput(event: KeyboardEvent) {
    if (event.keyCode === 27) {
      this.dismiss();
    }
  }

  ngOnInit() {
    if (this.time > 0) {
      setTimeout(() => {
        this.dismiss();
      }, this.time)
    }
  }

  dismiss() {
    this.result = {
      isClosed: true,
      action: false
    }
    this.close();
  }

  confirmAction() {
    this.result = {
      isClosed: true,
      action: true
    }
    this._auth.updatePassword(this.password).then(uData => {
      let message = 'Update Successful';
      this._notifier.display(true, message, 'success');
      setTimeout(() => {
        this.close();
        
      }, 3000)
    }).catch((err) => {
      this._notifier.display(true, err.message, 'fail');
    });

  }



  matchingPassword(passwordKey: string, confirmPasswordKey: string) {
    return (group: FormGroup): { [key: string]: any } => {
      let password = group.controls[passwordKey];
      let confirm_password = group.controls[confirmPasswordKey];
      if (password.value !== confirm_password.value) {
        return {
          mismatchedPasswords: true
        };
      }
    }
  }
}
