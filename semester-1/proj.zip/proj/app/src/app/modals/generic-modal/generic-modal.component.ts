import { Component, OnInit, ElementRef, ViewChild, HostListener } from '@angular/core';
import { DialogComponent, DialogService } from "ng2-bootstrap-modal";
import { GenericModalOpen, GenericModalClose } from '../../models/modals.model';

@Component({
  selector: 'app-generic-modal',
  templateUrl: './generic-modal.component.html',
  styleUrls: ['./generic-modal.component.css']
})

//Author Brian McGowan
export class GenericModalComponent extends DialogComponent<GenericModalOpen, GenericModalClose> implements OnInit {
  title = 'Error';
  html: string;
  time: -1;
  showActionButtons = false;

  constructor(dialogService: DialogService) {
    super(dialogService);
  }


  @HostListener('window:keyup', ['$event'])
  keyboardInput(event: KeyboardEvent) {
    if (event.keyCode === 27) {
      this.dismiss();
    }
  }

  ngOnInit() {
    if (this.time > 0) {
      setTimeout(() => {
        this.dismiss();
      }, this.time)
    }
  }

  dismiss() {
    this.result = {
      isClosed: true,
      action: false
    }
    this.close();
  }

  confirmAction(){
    this.result = {
      isClosed: true,
      action: true
    }
    this.close();
  }

}
