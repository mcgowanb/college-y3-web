import { isDate } from 'util';
import { DialogComponent, DialogService } from "ng2-bootstrap-modal";
import { PostModalClose, PostModalOpen } from '../../models/modals.model';
import { Component, OnInit, HostListener } from '@angular/core';
import * as moment from 'moment';

@Component({
  selector: 'app-post-modal',
  templateUrl: './post-modal.component.html',
  styleUrls: ['./post-modal.component.css']
})

//Author Brian McGowan
export class PostModalComponent extends DialogComponent<PostModalOpen, PostModalClose> implements OnInit {


  content: string;
  userID: number;
  threadID: number;
  title: string;

  constructor(dialogService: DialogService) {
    super(dialogService);
  }

  ngOnInit() {
  }

  @HostListener('window:keyup', ['$event'])  
  keyboardInput(event: KeyboardEvent) {
    if(event.keyCode === 27){
      this.dismiss();
    }
  }

  dismiss() {
    this.result = {
      content: this.content,
      modifiedDate: moment().format('YYYY/MM/DD HH:mm:ss'),
      isDirty: false,
      threadID: this.threadID
    }
    this.close();
  }

  save() {
    this.result = {
      content: this.content,
      isDirty: true,
      modifiedDate:  moment().format('YYYY/MM/DD HH:mm:ss'),
      threadID: this.threadID      
    }
    this.close()
  }
}
