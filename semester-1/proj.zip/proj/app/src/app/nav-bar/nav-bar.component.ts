/////////////////////////
// Kate O'Neill
///////////////////////////
import { AuthService } from '../services/auth.service';
import { DataService } from '../services/data.service';
import { CategoryList } from '../models/category';
import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import * as firebase from 'firebase/app';
@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css']
})
export class NavBarComponent implements OnInit {
  @Output() filterCategory = new EventEmitter<any>();
  public categoriesList: CategoryList[];
  public loading = true;
  public selectedCategory: number;
  public user:string;
  constructor(private _dataService: DataService, public auth: AuthService) { 
    this.user = localStorage.getItem('emailDisplay');
  }

  ngOnInit() {
   // this.selectedCategory = -1;

    this._dataService.getAllCategories().subscribe(res => {
      this.categoriesList = res;
      this.loading = false;
    }, (err) => {
      console.log(err);
    });
  }

  checkLoggedIn(){
    if(firebase.auth().currentUser)
    {
      
      return true;
    }
      else 
      return false;

  }
  loadCategory(categoryID: number, title: string) {
    this.selectedCategory = categoryID;
    this.filterCategory.emit({ categoryID: categoryID, categoryTitle: title });
  }

  logout() {
    
    this.auth.logout();
  }
}
