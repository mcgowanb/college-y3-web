import { BreadcrumbService } from './services/breadcrumb.service';
import { NotificationService } from './services/notification.service';
import { AuthService } from './services/auth.service';
import { LoginComponent } from './users/login/login.component';
import { GenericModalComponent } from './modals/generic-modal/generic-modal.component';
import { UrlSerializer } from '@angular/router';
import { CustomUrlSerializer } from './services/CustomUrlSerializer';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Routing } from './app.routing';
import { DataService } from './services/data.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Http, HttpModule } from '@angular/http';
import { AppComponent } from './app.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { CategoriesComponent } from './categories/categories.component';
import { BreadcrumbComponent } from './breadcrumb/breadcrumb.component';
import { ThreadComponent } from './thread/thread.component';
import { PostComponent } from './thread/post/post.component';
import { PostUserDetailsComponent } from './thread/post/post-user-details/post-user-details.component';
import { PostThanksComponent } from './thread/post/post-thanks/post-thanks.component';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { FollowedThreadsComponent } from './followed-threads/followed-threads.component';
import { ThreadsListComponent } from './threads-list/threads-list.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { PostButtonsComponent } from './thread/post/post-buttons/post-buttons.component';
import { ToastModule } from 'ng2-toastr/ng2-toastr';
import { BootstrapModalModule } from 'ng2-bootstrap-modal';
import { PostModalComponent } from './modals/post-modal/post-modal.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RegisterComponent } from './users/register/register.component';
import { NotificationComponent } from './notification/notification.component';
import { AngularFireModule } from 'angularfire2';
import { AngularFireAuthModule } from 'angularfire2/auth';
import { AngularFireDatabaseModule } from 'angularfire2/database';
import { environment } from '../environments/environment';
import { AuthGuard } from './services/auth.guard';
import { UserDetailsComponent } from './users/user-details/user-details.component';
import { NewThreadComponent } from './new-thread/new-thread.component';
import { PasswordModalComponent } from './modals/password-modal/password-modal.component';
import { EmailService } from './services/email.service';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    DashboardComponent,
    CategoriesComponent,
    BreadcrumbComponent,
    ThreadComponent,
    PostComponent,
    PostUserDetailsComponent,
    PostThanksComponent,
    NavBarComponent,
    FollowedThreadsComponent,
    ThreadsListComponent,
    PageNotFoundComponent,
    PostButtonsComponent,
    GenericModalComponent,
    PostModalComponent,
    RegisterComponent,
    NotificationComponent,
    UserDetailsComponent,
    NewThreadComponent,
    PasswordModalComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    FormsModule,
    ReactiveFormsModule,
    Routing,
    BrowserAnimationsModule,
    BrowserModule, ToastModule.forRoot(),
    BootstrapModalModule,
    AngularFireModule.initializeApp(environment.firebase),
   // AngularFireModule.initializeApp(environment.firebase, 'angular-auth-firebase'),
    AngularFireDatabaseModule,
    AngularFireAuthModule
  ],
  entryComponents: [
    GenericModalComponent,
    PostModalComponent,
    PasswordModalComponent
  ],
  providers: [DataService,
    { provide: UrlSerializer, useClass: CustomUrlSerializer },
    AuthService,
    NotificationService,
    AuthGuard,
    BreadcrumbService,
    EmailService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
