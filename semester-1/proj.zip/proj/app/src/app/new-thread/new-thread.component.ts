import {Router} from '@angular/router';
import {ToastsManager} from 'ng2-toastr/ng2-toastr';
import { DataService } from '../services/data.service';
import {AuthService} from '../services/auth.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { Thread } from '../models/thread';
import * as moment from 'moment';

@Component({
  selector: 'app-new-thread',
  templateUrl: './new-thread.component.html',
  styleUrls: ['./new-thread.component.css']
})
//Author Brian McGowan
export class NewThreadComponent implements OnInit {
  form: FormGroup;
  private _categories: any;
  public loading = true;
  public thread: Thread;

  constructor(private _fb: FormBuilder, private _auth: AuthService, private _data: DataService, public toastr: ToastsManager,
    private _router: Router) {
    this.form = _fb.group({
      category:  ['', Validators.required],
      title: ['', Validators.required],
      content: ['', Validators.required]
    });

    this.thread = new Thread();
    this.thread.userID = this._auth.userID;

   }

   ngSubmit(){
    this.thread.createdDate = moment().format('YYYY-MM-DD HH:MM:SS');
    this._data.createThread(this.thread).subscribe(result => {
      this._router.navigateByUrl('/');
    })
   }

  ngOnInit() {
    this.loadCategories()
  }

  loadCategories(){
    this._data.getAllCategories().subscribe(results => {
      this._categories = results;
      this.loading = false;
    })
  }

}
