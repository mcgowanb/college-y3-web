import { ActivatedRoute, NavigationEnd, Router, ActivatedRouteSnapshot } from '@angular/router';
import { ThreadList } from '../models/thread';
import { DataService } from '../services/data.service';
import { Component, EventEmitter } from '@angular/core';
import { BreadCrumb } from '../models/breadcrumb';
import { CategoryList } from '../models/category';
import { Observable } from 'rxjs';
import { BreadcrumbService } from '../services/breadcrumb.service';

@Component({
  selector: 'app-breadcrumb',
  templateUrl: './breadcrumb.component.html',
  styleUrls: ['./breadcrumb.component.css']
})

export class BreadcrumbComponent {
  public showBreadcrumb = true;
  public rootCrumb: BreadCrumb = { path: '/', text: 'Home', visible: true };
  public categoryCrumb: BreadCrumb = { path: '/', text: 'Category', visible: true };
  public pageCrumb: BreadCrumb = { path: '/', text: 'Page', visible: true };
  private currentUrl: string;
  private categoryId = '6';
  private categoryTitle = 'Category Title';
  private threadId = '22';
  public threadTitle = 'Thread Title';

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private _breadcrumbService: BreadcrumbService
  ) {

    //  Create the first set of breadcrumbs
    this.currentUrl = window.location.href;
    console.log(window.location.href);
    this.createCrumbs();

    //  Subscribe to navigation changes on the router and create new crumbs if changes occur
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.currentUrl = event.url;
        this.createCrumbs();
      }
    });
  }

  //  Function to check the url and display the breadcrumbs
  createCrumbs() {
    //  Breadcrumb roots
    if (this.currentUrl.indexOf('login') > -1) {
      this.rootCrumb.text = 'Login';
      this.showRootCrumb();
    } else if (this.currentUrl.indexOf('userDetails') > -1) {
      this.rootCrumb.text = 'Home';
      this.categoryCrumb.text = 'User Account';
      this.categoryCrumb.path = `/`;
      this.showCategoryCrumb();
    } else if (this.currentUrl.indexOf('register') > -1) {
      this.rootCrumb.text = 'Home';
      this.categoryCrumb.text = 'Register';
      this.categoryCrumb.path = `/`;
      this.showCategoryCrumb();
      // Breadcrumbs for categories calls breadcrumb service
    } else if (this.currentUrl.indexOf('category') > -1) {
      this.categoryId = this.currentUrl.substring(this.currentUrl.indexOf('=') + 1)
      this._breadcrumbService.getCategoryTitle(this.categoryId).subscribe((res) => {
        this.categoryTitle = res.text();
        this.categoryCrumb.text = this.categoryTitle;
        this.categoryCrumb.path = `/dashboard;category=${this.categoryId}`;
        this.showCategoryCrumb();
      });

      // Breadcrumbs for threads calls breadcrumb service
    } else if (this.currentUrl.indexOf('viewThread') > -1) {
      this.threadId = this.currentUrl.substring(this.currentUrl.lastIndexOf('/') + 1);
      this._breadcrumbService.getThreadCategoryTitle(this.threadId).subscribe((res) => {
        this.categoryTitle = res.text();
        this.showPageCrumb();
      });
      this._breadcrumbService.getThreadCategoryID(this.threadId).subscribe((res) => {
        this.categoryId = res.text();
        this.categoryCrumb.path = `/dashboard;category=${this.categoryId}`;
      });
      this._breadcrumbService.getThreadTitle(this.threadId).subscribe((res) => {
        this.threadTitle = res.text();
        this.pageCrumb.text = this.threadTitle;
        this.showPageCrumb();
      });
    } else if (this.currentUrl.indexOf('dashboard') > -1) {
      this.categoryCrumb.text = 'Dashboard';
      this.rootCrumb.text = 'Home';
      this.showCategoryCrumb();
    } else {
      this.rootCrumb = { path: '/', text: 'Home', visible: true };
      this.showRootCrumb();
    }
  }

  //  Function to change breadcrumbs visible
  showRootCrumb() {
    this.rootCrumb.visible = true;
    this.categoryCrumb.visible = false;
    this.pageCrumb.visible = false;
  }
  showCategoryCrumb() {
    this.rootCrumb.visible = true;
    this.categoryCrumb.visible = true;
    this.pageCrumb.visible = false;
  }
  showPageCrumb() {
    this.rootCrumb.visible = true;
    this.categoryCrumb.visible = true;
    this.pageCrumb.visible = true;
  }
}
