import { AuthService } from '../../services/auth.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { stripTrailingSlash } from 'angularfire2/database-deprecated/utils';
import { Component, OnInit } from '@angular/core';
import { User } from '../../models/user';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  public name: string;
  public userName: string;
  public email: string;
  public password: string;
  public confirmPassword: string;
  ngForm: FormGroup;
  private user: User;

  constructor(private _fb: FormBuilder, private _auth: AuthService) {
    this.createForm();
    this.user = new User();
  }

  createForm() {
    this.ngForm = this._fb.group({
      email: ['', Validators.email],
      name: ['', Validators.required],
      userName: ['', Validators.required],
      password: ['', Validators.compose([Validators.required])],
      confirmPassword: ['', Validators.compose([Validators.required])]
    }, { validator: this.matchingPassword('password', 'confirmPassword') })
  }

  ngOnInit() {
  }

  ngSubmit() {
    this.user.Name = this.name;
    this.user.UserName = this.userName;
    this.user.Email = this.email;
    this.user.Password = this.password;
    this._auth.register(this.user);
    
  }


  matchingPassword(passwordKey: string, confirmPasswordKey: string) {
    return (group: FormGroup): { [key: string]: any } => {
      let password = group.controls[passwordKey];
      let confirm_password = group.controls[confirmPasswordKey];

      if (password.value !== confirm_password.value) {
        return {
          mismatchedPasswords: true
        };
      }
    }
  }
}
