///////////////////////////////
// Kate O'Neill
////////////////////////////////
import { GenericModalClose } from '../../models/modals.model';
import { PasswordModalComponent } from '../../modals/password-modal/password-modal.component';
import { DialogService } from 'ng2-bootstrap-modal/dist';
import { DataService } from '../../services/data.service';
import { AuthService } from '../../services/auth.service';
import { User } from '../../models/user';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.css']
})
export class UserDetailsComponent implements OnInit {
   public name: string;
  public userName: string;
  public email: string;
  public password: string;
  public confirmPassword: string;
  ngForm: FormGroup;
  private user: User;
  private userID: string;
  public isModalOpen = false;

  constructor(private _fb: FormBuilder, private _auth: AuthService,private _dataService: DataService , private _dialogService: DialogService) {
    this.createForm();
  
        this.userID = _auth.userID;
    this.user = new User ();

  }

  createForm() {
    this.ngForm = this._fb.group({
      name: ['', Validators.required],
      userName: ['', Validators.required],

  });
  }

  ngOnInit() {
    this.name = this._auth.userDetails.Name;
    this.userName = this._auth.userDetails.UserName;
    this.email =this._auth.userDetails.EmailAddress;
  }

  ngSubmit() {

    this._auth.userDetails.Name = this.name;
    this._auth.userDetails.UserName = this.userName;
    this._auth.userDetails.Email = this.email;   
    this._auth.userDetails.UserID = this._auth.userID;
    this._auth.updateUser(this._auth.userDetails);

  }

  matchingPassword(passwordKey: string, confirmPasswordKey: string) {
    return (group: FormGroup): { [key: string]: any } => {
      let password = group.controls[passwordKey];
      let confirm_password = group.controls[confirmPasswordKey];

      if (password.value !== confirm_password.value) {
        return {
          mismatchedPasswords: true
        };
      }
    }
  }
  changePassword(){
    this.isModalOpen = true;
    this._dialogService.addDialog(PasswordModalComponent, {
      html: `<h1>Are you sure you want to delete this post?</h1><p><small> Deleting is permanant and cannot be undone</small></p>`,
      showActionButtons: true,
      title: 'Change Password'
    }).subscribe((result: GenericModalClose) => {
      this.isModalOpen = false;
      if (result.action) {
      }
    });
  }


}
