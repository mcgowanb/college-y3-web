import { AuthService } from '../../services/auth.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  email: string;
  password: string;
  form: FormGroup;
  constructor(private _fb: FormBuilder, private _auth: AuthService) { 
    this.email = '';
    this.password = '';

    this.form = _fb.group({
      email:  ['', Validators.email],
      password: ['', Validators.required]
    });
  }

  ngOnInit() {
  }

  ngSubmit(){
    this._auth.login(this.email, this.password);
  }

  isFormValid(){
    return (this.email.length == 0 || this.password.length == 0) ? true : false
  }

}
