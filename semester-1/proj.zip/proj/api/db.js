////////////////////////////////////////
/////AUTH: Brian McGowan
////////////////////////////////////////
var mysql = require('mysql');

var connection = mysql.createPool({
    multipleStatements: true,
    connectionLimit: 10,
    host: 'web-y3-project.cg54g10jyahd.us-west-2.rds.amazonaws.com',
    user: 'root_admin',
    password: 'OpenSesame5656',
    database: 'forum'
});

module.exports = connection;  