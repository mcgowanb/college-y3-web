////////////////////////////////////////
/////AUTH: Brian McGowan
////////////////////////////////////////
const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const mysql = require('mysql');
const db = require('./db');

app.use(bodyParser.json());
port = process.env.PORT || 8080;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());


const cors = require('cors');
var corsOptions = {
    origin: 'https://secure-cove-75663.herokuapp.com',
}

app.use(cors(true));

var routes = require('./routes/routes');
routes(app);

app.use((req, res) => {
    res.status(404).send({ url: req.originalUrl + ' not found' });
});


db.getConnection(function (err, connection) {
    if (err) console.log(err)
    else console.log("db connection Successful");
});

app.listen(port, () => {
    console.log('Node app is running on port ' + port);
});
