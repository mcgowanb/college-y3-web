//  Email Notifier using Node Mailer
//  Development Email server in use: Ethereal Mail 
//  A url to all test emails is logged to the console

var db = require('../db');

//  Function to query the database for the title and author email by threadID
exports.sendAuthorThreadUpdate = (req, res) => {
    const threadID = req.params.id;
    db.query(`SELECT Title, EmailAddress FROM threads JOIN users ON threads.UserID = users.UserID WHERE ThreadID=${threadID}`, (err, result) => {
        if (err) {
            console.log(err)
        } else {
            this.emailNotification(req.params.id, result[0].EmailAddress, result[0].Title)
        }
    });
}

//  Function to Email Author if Thread Changes
exports.emailNotification = (threadID, userEmail, threadTitle ) => {
    const nodemailer = require('nodemailer');
    nodemailer.createTestAccount((err, account) => {
        const transporter = nodemailer.createTransport({
            host: 'smtp.yandex.com',
            port: 465,
            auth: {
                user: 'projectinforum',
                pass: 'OpenSesame6677'
            }
        });
        let mailOptions = {
            from: '"IN FORUM NOTIFIER" <projectinforum@yandex.com>',
            to: `${userEmail}`,
            subject: `${threadTitle} has been updated.`,
            text: `Your thread ${threadTitle} has been updated.`,
            html: `Your thread <a href="https://secure-cove-75663.herokuapp.com/viewThread/${threadID}">${threadTitle}</a> has been updated.`
        };
        transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
                return console.log(error);
            }
            console.log('Message sent: %s', info.messageId);
            console.log('Preview URL: %s', nodemailer.getTestMessageUrl(info));
        });
    });
}

//  Function to Test NodeMailer 
//  This function has been left in to debug email sending
exports.sendTestEmail = () => {
    const nodemailer = require('nodemailer');
    nodemailer.createTestAccount((err, account) => {
        const transporter = nodemailer.createTransport({
            host: 'smtp.yandex.com',
            port: 465,
            auth: {
                user: 'projectinforum',
                pass: 'OpenSesame6677'
            }
        });
        let mailOptions = {
            from: 'projectinforum@yandex.com',
            to: 'bryan@kerruish.ie',
            subject: 'Hello ✔', // Subject line
            text: 'Hello world?', // plain text body
            html: '<b>Hello world?</b>' // html body
        };
        transporter.sendMail(mailOptions, (error, info) => {
            if (error) {
                return console.log(error);
            }
            console.log('Message sent: %s', info.messageId);
            console.log('TEST')
        });
    });
}