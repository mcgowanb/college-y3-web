var db = require('../db');
var async = require('async');
var threadTable = 'threads';
var tfTable = 'threadfollows';
var catTable = 'categories';
var userTable = 'users';
var postsTable = 'posts';
var pThanks = 'postThanks';

////////////////////////////////////////
/////AUTH: Brian McGowan
////////////////////////////////////////

exports.list = (req, res) => {
    var query = `SELECT ${threadTable}.ThreadID as ThreadID, ${catTable}.Name as CategoryName, ${threadTable}.UserID AS UserID, ${userTable}.UserName as User, ${threadTable}.Title as Title,
    ${threadTable}.Rating as Rating, ${threadTable}.Created as CreatedDate, (SELECT COUNT(*) FROM ${postsTable} WHERE ${postsTable}.ThreadID=${threadTable}.ThreadID) AS PostCount FROM ${threadTable} 
    LEFT JOIN ${catTable} ON ${catTable}.CategoryID = ${threadTable}.CategoryID LEFT JOIN ${userTable} ON ${userTable}.UserID = ${threadTable}.UserID`;

    if (req.query.categoryID) {
        query += ` WHERE ${threadTable}.CategoryID=${req.query.categoryID} `
    }

    query += ` ORDER BY ${threadTable}.Created DESC`;

    db.query(query, (err, results) => {
        if (err) {
            res.send(err);
        }
        else {
            res.send(results);
        }
    });
}

exports.create = (req, res) => {      
    var tQuery = `INSERT INTO ${threadTable} (CategoryID, UserID, Title) VALUES(?,?,?)`;
    var pQuery = `INSERT INTO ${postsTable} (UserID, ThreadID, Content) VALUES(?,?,?)`;
    var uQuery = `UPDATE ${userTable} SET PostCount=PostCount+1 WHERE UserID=?`;

    db.query(tQuery, [req.body.categoryID, req.body.userID, req.body.title], (err, result) => {
        let threadID = result.insertId;
        db.query(pQuery, [req.body.userID, threadID, req.body.body], (err, result) => {
            if (err) {
                res.send(err);
            }
            else {
                db.query(uQuery, [req.body.userID], (er, result) => {
                    if (err) {
                        res.send(err);
                    }
                    else res.send(result)
                })
            }
        });
    });
}


exports.deleteThreadCascading = (req, res) => {
    var tfQuery = `DELETE FROM ${tfTable} WHERE ThreadFollows.ThreadID=?`;
    var ptQuery = `DELETE FROM ${pThanks} WHERE ${pThanks}.PostID IN (SELECT PostID FROM ${postsTable} WHERE ${postsTable}.ThreadID=?)`;
    var tQuery = `DELETE FROM ${threadTable} WHERE ${threadTable}.ThreadID =?;`;
    var pQuery = `DELETE FROM ${postsTable} WHERE ${postsTable}.ThreadID =?`;
    var return_data = {};

    async.parallel(
        [
            (done) => {
                //delte post thanks
                db.query(ptQuery, [req.params.id], function (err, results) {
                    if (err) return done(err);
                    return_data.ptRes = results;
                    done();
                });
            },
            (done) => {
                //delte thread follows
                db.query(tfQuery, [req.params.id], function (err, results) {
                    if (err) return done(err);
                    return_data.tfRes = results;
                    done();
                });
            },
            (done) => {
                //delete thread query
                db.query(tQuery, [req.params.id], function (err, results) {
                    if (err) return done(err);
                    return_data.tRes = results;
                    done();
                });
            },
            (done) => {
                //delte post query
                db.query(pQuery, [req.params.id], function (err, results) {
                    if (err) return done(err);
                    return_data.pRes = results;
                    done();
                });
            }
        ], (err) => {
            if (err) console.log(err);
            res.send(return_data);
        }
    );

}

exports.getThread = (req, res) => {
    var tQuery = `SELECT * FROM ${threadTable} WHERE ${threadTable}.ThreadID =?;`;
    var pQuery = `SELECT p.PostID, p.UserID, p.ThreadID, p.Content, p.Created, u.UserName, u.RegistrationDate, u.PostCount FROM ${postsTable} as p LEFT JOIN ${userTable} as u ON u.UserID = p.UserID WHERE p.ThreadID =?`;
    var return_data = { "thread": {}, "posts": {} };

    async.parallel(
        [
            (done) => {
                db.query(tQuery, [req.params.id], function (err, results) {
                    if (err) return done(err);
                    return_data.thread = results[0];
                    done();
                });
            },
            (done) => {
                db.query(pQuery, [req.params.id], function (err, results) {
                    if (err) return done(err);
                    return_data.posts = results;
                    done();
                });
            }
        ], (err) => {
            if (err) console.log(err);
            res.send(return_data);
        }
    );
}




exports.update = (req, res) => {
    var tQuery = `UPDATE ${threadTable} SET Title=? WHERE ThreadID=?`;
    db.query(tQuery, [req.body.title, req.body.threadID], (err, result) => {
        if (err) {
            res.send(err);
        }
        else {
            res.send(result);
        }
    });
}

exports.followed = (req, res) => {
    var query = `SELECT ${threadTable}.ThreadID, ${threadTable}.Title, ${threadTable}.Rating FROM ${threadTable} WHERE ${threadTable}.ThreadID IN(SELECT ${tfTable}.ThreadID FROM ${tfTable} WHERE ${tfTable}.UserID = ${req.params.userID})`;
    db.query(query, (err, results) => {
        if (err)
            res.send(err);
        else res.send(results);
    });
}

//Added by Kate//////////////////////////////
exports.doIFollow = (req, res) => {
    var query = `SELECT * FROM ${tfTable} WHERE ${tfTable}.UserID = ${req.params.userID}`;
    db.query(query, (err, results) => {
        if (err)
            res.send(err);
        else res.send(results);
    });
}
////////////////////////////////////////////
