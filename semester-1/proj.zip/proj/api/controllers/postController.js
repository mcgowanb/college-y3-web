var db = require('../db');
var async = require('async');
var tableName = 'posts';
var userTable = 'users';
var ptTable = 'postThanks';

var pk = 'PostID';

////////////////////////////////////////
/////AUTH: Brian McGowan
////////////////////////////////////////

exports.list = (req, res) => {
    var query = `SELECT ${tableName}.PostID as PostID, ${tableName}.ThreadID as ThreadID, ${tableName}.Content as Content, ${tableName}.UserID as UserID, ${tableName}.Created as Created,
    ${userTable}.UserName as UserName, ${userTable}.Name as Name, ${userTable}.PostCount as PostCount  FROM ${tableName} 
    LEFT JOIN ${userTable} ON ${tableName}.UserID = ${userTable}.UserID`;
    //filter by thread id
    if (req.query.threadID) {
        query = query + ` WHERE ${tableName}.ThreadID = ${req.query.threadID}`;
    }

    query = query + ` ORDER BY Created ASC`;
    db.query(query, (err, results) => {
        if (err) {
            res.send(err);
        }
        else {
            res.send(results);
        }
    });
}

exports.create = (req, res) => {
    var insertQuery = `INSERT INTO ${tableName} (UserID, ThreadID, Content) VALUES (?, ?, ?)`;
    var updateUserQry = `UPDATE ${userTable} SET PostCount = PostCount +1 WHERE UserID = ?`;
    var return_data = {
        ok: false
    }

    async.parallel(
        [
            (done) => {
                db.query(insertQuery,
                    [req.body.userID, req.body.threadID, req.body.content], (err, results) => {
                        if (err) return done(err);
                        return_data.ok = true;
                        done();
                    });
            },
            (done) => {
                db.query(updateUserQry, [req.body.userID], (err, results) => {
                        if (err) return done(err);
                        return_data.ok = true;
                        done();
                    });
            },
        ], (err) => {
            if (err) console.log(err);
            res.send(return_data);
        }
    );

}

exports.delete = (req, res) => {
    //also need to delete the user id 
    var query1 = `DELETE FROM ${tableName} WHERE ${pk}=?`;
    var query2 = `UPDATE ${userTable} SET PostCount = PostCount -1 WHERE UserID = ?`;

    var return_data = {
        ok: false
    }

    async.parallel(
        [
            (done) => {
                db.query(query1, [req.params.id], function (err, results) {
                    if (err) return done(err);
                    return_data.ok = true;
                    done();
                });
            },
            (done) => {
                db.query(query2, [req.query.userID], function (err, results) {
                    if (err) return done(err);
                    return_data.ok = true;
                    done();
                });
            }
        ], (err) => {
            if (err) console.log(err);
            res.send(return_data);
        }
    );
}

exports.getSingle = (req, res) => {
    db.query(`SELECT * FROM ${tableName} WHERE ${pk}=? LIMIT 1`, [req.params.id], (err, result) => {
        if (err) {
            res.send(err);
        }
        else {
            res.send(result[0]);
        }
    });
}

exports.update = (req, res) => {
    db.query(`UPDATE ${tableName} SET Content=?, Created=? WHERE ${pk}=?`, [req.body.content, req.body.modifiedDate, req.body.postID], (err, result) => {
        if (err) {
            res.send(err);
        }
        else {
            res.send(result);
        }
    });
}

exports.thankedPosts = (req, res) => {
    var query = `SELECT ${tableName}.PostID as PostID, ${tableName}.ThreadID as ThreadID, ${tableName}.Content as Content, ${tableName}.UserID as UserID, ${tableName}.Created as Created,
    ${userTable}.UserName as UserName, ${userTable}.Name as Name, ${userTable}.PostCount as PostCount  FROM ${tableName} 
    LEFT JOIN ${userTable} on Post.UserID = ${userTable}.UserID  WHERE ${tableName}.PostID IN (SELECT PostID FROM ${ptTable} WHERE UserID = ${req.body.userID}) `;
    //filter by thread id
    db.query(query, (err, results) => {
        if (err) {
            res.send(err);
        }
        else {
            res.send(results);
        }
    });
}