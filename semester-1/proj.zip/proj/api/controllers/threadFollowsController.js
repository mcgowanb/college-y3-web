var db = require('../db');
var tableName = 'threadfollows';

////////////////////////////////////////
/////AUTH: Brian McGowan
////////////////////////////////////////

exports.follow = (req, res) => {
    db.query(`INSERT INTO ${tableName} (ThreadID, UserID) VALUES (?, ?)`, [req.body.tid, req.body.uid], (err, results) => {
        if (err) {
            res.send(err);
        }
        else {
            res.send(results);
        }
    });
}

exports.unFollow = (req, res) => {
    db.query(`DELETE FROM ${tableName} WHERE ThreadID = ? AND UserID = ?`, [req.body.tid, req.body.uid], (err, results) => {
        if (err) {
            res.send(err);
        }
        else {
            res.send(results);
        }
    });
}