var db = require('../db');
var tableName = 'postthanks';
var userTable = 'users';

////////////////////////////////////////
/////AUTH: Brian McGowan
////////////////////////////////////////

exports.addThanks = (req, res) => {
    db.query(`INSERT INTO ${tableName} (PostID, UserID) VALUES (?, ?)`, [req.body.pid, req.body.uid], (err, results) => {
        if (err) {
            res.send(err);
        }
        else {
            res.send(results);
        }
    });
}

exports.removeThanks = (req, res) => {
    db.query(`DELETE FROM ${tableName} WHERE PostID = ? AND UserID = ?`, [req.body.pid, req.body.uid], (err, results) => {
        if (err) {
            res.send(err);
        }
        else {
            res.send(results);
        }
    });
}

exports.getThanks = (req, res) => {
    db.query(`SELECT thanks.UserID, users.UserName FROM ${tableName} as thanks INNER JOIN ${userTable} ON ${userTable}.UserID = thanks.UserId AND PostID = ?;`, [req.query.pid], (err, results) => {
        if (err) {
            res.send(err);
        }
        else {
            res.send(results);
        }
    });
}