//  Breadcrumb controller
//  All logic and functions necessary for the breadcrumb component

var db = require('../db');

//  Function to get the name of a category based on category ID
exports.getCategoryTitle = (req, res) => {
    if (req.params.id != null)
        db.query(`SELECT Name FROM categories WHERE CategoryID=?`, [req.params.id], (err, result) => {
            if (err) {
                res.send(err);
            } else {
                res.send(result[0].Name);
            }
        });
}
//  Function to get the title of a thread based on thread ID
exports.getThreadTitle = (req, res) => {
    if (req.params.id != null)
        db.query(`SELECT Title FROM threads WHERE ThreadID=?`, [req.params.id], (err, result) => {
            if (err) {
                res.send(err);
            } else {
                res.send(result[0].Title);
            }
        });
}
//  Function to get the category id of a thread based on thread ID
exports.getThreadCategoryID = (req, res) => {
    if (req.params.id != null)
        db.query(`SELECT CategoryID FROM threads WHERE ThreadID=?`, [req.params.id], (err, result) => {
            if (err) {
                res.send(err);
            } else {
                res.send(result[0].CategoryID.toString());
            }
        });
}
//  Function to get the category title of a thread based on thread ID
exports.getThreadCategoryTitle = (req, res) => {
    if (req.params.id != null)
        db.query(`SELECT Name FROM threads JOIN categories ON threads.CategoryID = categories.CategoryID WHERE ThreadID=?`, [req.params.id], (err, result) => {
            if (err) {
                res.send(err);
            } else {
                res.send(result[0].Name);
            }
        });
}
