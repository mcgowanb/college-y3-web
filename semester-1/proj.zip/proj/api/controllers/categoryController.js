var db = require('../db'); 
var tableName = 'categories';
var threadsTable = 'threads';

////////////////////////////////////////
/////AUTH: Brian McGowan
////////////////////////////////////////
exports.list = (req, res) => {
    db.query(`SELECT ${tableName}.CategoryID AS CategoryID, ${tableName}.Name AS Name, (SELECT COUNT(*) FROM ${threadsTable} WHERE ${threadsTable}.CategoryID=${tableName}.CategoryID ) AS Threads FROM ${tableName} ORDER BY Threads DESC`, (err, results) => {
        if (err) {
            res.send(err);
        }
        else {
            res.send(results);
        }
    });
}

exports.create = (req, res) => {
    db.query(`INSERT INTO ${tableName} (Name) VALUES (?)`, [req.body.name], (err, result) => {
        if (err) {
            res.send(err);
        }
        else {
            console.log(`1 record inserted`);
            res.send(result)
        }
    });
}

exports.delete = (req, res) => {
    db.query(`DELETE FROM ${tableName} WHERE CategoryID=?`, [req.params.id], (err, result) => {
        if (err) {
            res.send(err);
        }
        else {
            res.send(result)
        }
    });
}

exports.getSingle = (req, res) => {
    db.query(`SELECT * FROM ${tableName} WHERE CategoryID=?`, [req.params.id], (err, result) => {
        if (err) {
            res.send(err);
        }
        else {
            res.send(result[0]);
        }
    });
}

exports.update = (req, res) => {
    db.query(`UPDATE ${tableName} SET Name=? WHERE CategoryID=?`, [req.body.name, req.body.id], (err, result) => {
        if (err) {
            res.send(err);
        }
        else {
            res.send(result);
        }
    });
}