var db = require('../db');
var tableName = 'users';
var pk = 'UserID';

////////////////////////////////////////
/////AUTH: Brian McGowan
////////////////////////////////////////

exports.list = (req, res) => {
    db.query(`SELECT * FROM ${tableName}`, (err, results) => {
        if (err) {
            res.send(err);
        }
        else {
            res.send(results);
        }
    });
}

exports.create = (req, res) => {
    db.query(`INSERT INTO ${tableName} (UserName, Name, EmailAddress, Uid) VALUES (?, ?, ?, ?)`,
        [req.body.UserName, req.body.Name, req.body.Email, req.body.Uid],
        (err, result) => {
            if (err) {
                res.send(err);
            }
            else {
                res.send(result)
            }
        });
}

exports.delete = (req, res) => {
    db.query(`DELETE FROM ${tableName} WHERE ${pk}=?`, [req.params.id], (err, result) => {
        if (err) {
            res.send(err);
        }
        else {
            res.send(result)
        }
    });
}

exports.getSingle = (req, res) => {
    db.query(`SELECT * FROM ${tableName} WHERE Uid=? LIMIT 1`, [req.params.id], (err, result) => {
        if (err) {
            res.send(err);
        }
        else {
            if(result.length === 0){
                result[0] = '{}'
            }
            res.send(result[0]);
        }
    });
}

exports.update = (req, res) => {
    db.query(`UPDATE ${tableName} SET UserName=?, Name=?, EmailAddress=? WHERE ${pk}=?`, [req.body.UserName, req.body.Name, req.body.Email, req.body.UserID], (err, result) => {
        if (err) {
            res.send(err);
        }
        else {
            res.send(result);
        }
    });
}