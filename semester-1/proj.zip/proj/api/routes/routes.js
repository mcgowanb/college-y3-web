module.exports = (app) => {
    var categories = require('../controllers/categoryController');
    var posts = require('../controllers/postController');
    var users = require('../controllers/userController');    
    var threads = require('../controllers/threadController');    
    var postThanks = require('../controllers/postThanksController');    
    var threadFollows = require('../controllers/threadFollowsController');    
    var breadcrumb = require('../controllers/breadcrumbController'); 
    var email = require('../controllers/emailController');

    ////////////////////////////////////////
    /////AUTH: Brian McGowan
    ////////////////////////////////////////
    app.route('/categories')
        .get(categories.list)
        .post(categories.create)
        .put(categories.update);

    app.route('/categories/:id')
        .delete(categories.delete)
        .get(categories.getSingle)

    app.route('/posts')
        .get(posts.list)
        .post(posts.create)
        .put(posts.update);

    app.route('/posts/:id')
        .delete(posts.delete)
        .get(posts.getSingle);

    app.route('/users')
        .get(users.list)
        .post(users.create)
        .put(users.update);

    app.route('/users/:id')
        .delete(users.delete)
        .get(users.getSingle);

    app.route('/threads')
        .get(threads.list)
        .post(threads.create)
        .put(threads.update);

    app.route('/threads/:id')
        .delete(threads.deleteThreadCascading)
        .get(threads.getThread);

    app.route('/thanks/add')
        .post(postThanks.addThanks);

    app.route('/thanks/remove')
        .post(postThanks.removeThanks);

    app.route('/thanks')
        .get(postThanks.getThanks);


    app.route('/threads/follow')
        .post(threadFollows.follow);

    app.route('/threads/unfollow')
        .post(threadFollows.unFollow);

    app.route('/thread/followed/:userID')
        .get(threads.followed);

    app.route('/threads/myFollowedThreads/:userID')
    .get(threads.doIFollow);
////////////////////////////////////////
/////AUTH-END: Brian McGowan
////////////////////////////////////////

    app.route('/breadcrumb/category/:id')
        .get(breadcrumb.getCategoryTitle);

    app.route('/breadcrumb/thread/:id')
        .get(breadcrumb.getThreadTitle);

    app.route('/breadcrumb/threadcategoryid/:id')
        .get(breadcrumb.getThreadCategoryID);

    app.route('/breadcrumb/threadcategoryname/:id')
        .get(breadcrumb.getThreadCategoryTitle);

    app.route('/email/sendTestEmail')
        .get(email.sendTestEmail);

    app.route('/email/sendAuthorThreadUpdate/:id')
        .get(email.sendAuthorThreadUpdate);
        
}